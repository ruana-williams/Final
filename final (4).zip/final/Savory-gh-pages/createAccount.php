<?php

$con = mysqli_connect('localhost','root','');

mysqli_select_db($con,'final');

$sql = "INSERT INTO 'users'(username, email, password ) VALUES ('$_POST[username]', '$_POST[email]', '$_POST[password]')";

if ($con->query($sql) == TRUE) {
    echo "User Registered Successfully.";
	header("refresh:3,index.html");
        
    }
    else {
   
    echo $con->error;
    header("refresh:3,index.html");
    }
    $con->close();
    ?>
